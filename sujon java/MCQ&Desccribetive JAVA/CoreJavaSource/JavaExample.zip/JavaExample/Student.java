
public class Student{
	
	public static void main(String[] args){
		System.out.println("Hello World");
		m1();
	}
	
	Student x=new Student();
	public void m1(){
		System.out.println("Parves");
	}
}