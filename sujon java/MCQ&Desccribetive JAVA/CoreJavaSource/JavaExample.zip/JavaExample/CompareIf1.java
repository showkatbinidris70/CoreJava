import java.util.Scanner;
public class CompareIf1{
	
	public static void main(String[] args){
	
		int m,n;
		/* Scanner sc=new Scanner(System.in);
		
		System.out.print("Value for Bangla ");
		m =sc.nextInt();
		
		System.out.print("Value for English ");
		n =sc.nextInt(); */
		
		int m=5;
		int n=3;
		
	
	
		if(m>n){
			if(n<m){
			System.out.println("Hello");	
			}
			System.out.println("Bangladesh!");
		}else if(n>m){
			System.out.println("Bangladesh");	
		}if(m>n){
			System.out.print("Dhaka");	
		}
	}
	
}