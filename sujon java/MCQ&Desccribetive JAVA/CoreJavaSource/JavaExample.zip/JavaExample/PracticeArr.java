
public class PracticeArr{
	
	public static void main(String[] args){
		int[] p = new int[5];
			p[0] =145;
			p[1] =452;
			p[2] =123;
			p[3] =782;
			p[4] =45;
			
		System.out.println(p[0]+","+p[1]+","+p[2]+","+p[3]+","+p[4]);
		/* System.out.println(p[1]);
		System.out.println(p[2]);
		System.out.println(p[3]);
		System.out.println(p[4]); */
	
	}
	
}